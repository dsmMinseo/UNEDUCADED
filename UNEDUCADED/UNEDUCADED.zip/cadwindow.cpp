﻿#include "cadwindow.h"

CADWindow::CADWindow(QWidget *parent) : QWidget(parent)
{
;
}
