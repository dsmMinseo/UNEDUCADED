#ifndef CADWINDOW_H
#define CADWINDOW_H

#include <QWidget>

class CADWindow : public QWidget
{
    Q_OBJECT
public:
    explicit CADWindow(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // CADWINDOW_H